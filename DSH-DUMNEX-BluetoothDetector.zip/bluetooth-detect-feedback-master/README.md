# bluetooth-detect-feedback
Bluetooth detection with RPI and Python.
